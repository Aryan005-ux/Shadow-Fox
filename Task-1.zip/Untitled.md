# Python Visualization Libraries Guide: Matplotlib and Seaborn

# 1.Library Overview

## Matplotlib
<p>Matplotlib is one of the most widely used 2D plotting libraries in Python. It provides an object-oriented API for embedding plots into applications using general-purpose GUI toolkits.</p>
<ul>Features:
<li>Fine-grained control over plot elements</li>
<li>Supports a wide range of plot types</li>
<li>Suitable for static and publication-quality visualizations</li>
        </ul>
<ul>Use Cases:
<li>Data exploration and analysis</li>
<li>Creating plots for academic publications</li>
<li>Customizing plot appearance extensively</li>
</ul>


## Seaborn
<p>Seaborn is built on top of Matplotlib and provides a high-level interface for drawing attractive and informative statistical graphics.</p>
<ul>Key Features:
<li>Built-in themes for styling Matplotlib graphics</li>
<li>Simplifies complex visualizations with less code</li>
<li>Built-in support for Pandas DataFrames</li>
</ul>

<ul>Use Cases:
<li>Statistical data visualization</li>
<li>Heatmaps, categorical plots, and complex relational plots</li>
<li>Quick exploratory data analysis</li>
</ul>

# 2.Graph Types

## Matplotlib

<b>a. Line Plot</b>
<p>Description: Represents data as a series of points connected by straight lines.</p>
<p>Use Case: Time series, trend analysis.</p>



```python
import matplotlib.pyplot as plt
x = [1, 2, 3, 4]
y = [10, 20, 25, 30]
plt.plot(x, y)
plt.title('Line Plot')
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.show()

```


    
![png](output_7_0.png)
    


<b>b. Bar Chart</b>
<p>Description: Displays categorical data with rectangular bars.</p> 
<p>Use Case: Comparing quantities across categories.</p>



```python
categories = ['A', 'B', 'C']
values = [10, 15, 7]
plt.bar(categories, values)
plt.title('Bar Chart')
plt.show()

```


    
![png](output_9_0.png)
    


<b>c. Histogram</b>
<p>Description: Shows frequency distribution of numeric data.</p>
<p>Use Case: Analyzing data distribution.</p>





```python
data = [1, 2, 2, 3, 3, 3, 4, 4, 5]
plt.hist(data, bins=5)
plt.title('Histogram')
plt.show()

```


    
![png](output_11_0.png)
    


<b>d. Scatter Plot</b>
<p>Description: Displays values for two variables using Cartesian coordinates.</p>
<p>Use Case: Identifying relationships between variables</p>




```python
x = [1, 2, 3, 4, 5]
y = [5, 4, 3, 2, 1]
plt.scatter(x, y)
plt.title('Scatter Plot')
plt.show()

```


    
![png](output_13_0.png)
    


<b>e. Pie Chart</b>
<p>Description: Represents proportions of a whole as slices.</p>
<p>Use Case: Showing percentage breakdown</p>
 



```python
labels = ['A', 'B', 'C']
sizes = [40, 35, 25]
plt.pie(sizes, labels=labels, autopct='%1.1f%%')
plt.title('Pie Chart')
plt.show()

```


    
![png](output_15_0.png)
    


## Seaborn

<b>a. Line Plot</b>
<p>Description: Enhanced line plots using built-in support for data frames.</p>
<p>Use Case: Time-series with confidence intervals.</p>
 



```python
import seaborn as sns
import pandas as pd

data = pd.DataFrame({"x": [1, 2, 3, 4], "y": [1, 4, 9, 16]})
sns.lineplot(x="x", y="y", data=data)

```




    <Axes: xlabel='x', ylabel='y'>




    
![png](output_18_1.png)
    


<b>b. Bar Plot</b>
<p>Description: Statistical summary of data with error bars.</p>
<p>Use Case: Category comparison with confidence intervals.</p>
 



```python
sns.barplot(x=["A", "B", "C"], y=[10, 20, 15])
```




    <Axes: >




    
![png](output_20_1.png)
    


<b>c. Histogram (displot)</b>
<p>Description: Univariate distribution of observations.</p>
<p>Use Case: Viewing distribution shape.</p>
 



```python
data = [1, 2, 2, 3, 4, 5, 6]
sns.displot(data, bins=5)

```




    <seaborn.axisgrid.FacetGrid at 0x17039420ad0>




    
![png](output_22_1.png)
    


<b>d. Scatter Plot</b>
<p>Description: Relationship between two variables with styling options.</p>
<p>Use Case: Visualizing correlations.</p>
 



```python
df = pd.DataFrame({'x': [1,2,3,4], 'y':[4,3,2,1]})
sns.scatterplot(x='x', y='y', data=df)

```




    <Axes: xlabel='x', ylabel='y'>




    
![png](output_24_1.png)
    


<b>e. Box Plot</b>
<p>Description: Displays distribution and outliers.</p>
<p>Use Case: Comparing groups.</p>
 



```python
sns.boxplot(data=[1, 2, 5, 7, 8, 8, 9])
```




    <Axes: >




    
![png](output_26_1.png)
    


<b>f. Heatmap</b>
<p>Description: Matrix of values with color encoding.</p>
<p>Use Case: Correlation matrix.</p>
 



```python
import numpy as np
corr = np.corrcoef([[1, 2, 3], [4, 5, 6]])
sns.heatmap(corr, annot=True)

```




    <Axes: >




    
![png](output_28_1.png)
    


### <b>3. Comparison: Matplotlib vs Seaborn<b>
### 1. Ease of Use
<b>Matplotlib:</b>

#Steeper learning curve; requires more code for basic plots.

#Offers full control but is more verbose.

<b>Seaborn:</b>

#Easier to use with concise, high-level functions.

#Great for quickly creating attractive statistical plots.

### 2. Customization Options
<b>Matplotlib:</b>

#Highly customizable; every aspect of the plot can be tweaked.

#Ideal for complex, publication-ready visualizations.

<b>Seaborn:</b>

#Limited to predefined styles and functions.

#For advanced customizations, often requires dropping down to Matplotlib.

### 3. Interactivity
<b>Matplotlib:</b>

#Basic interactivity (zoom, pan) through backends like %matplotlib notebook.

#Can integrate with interactive tools (e.g., Plotly, ipywidgets).

<b>Seaborn:</b>

#Minimal interactivity; built mainly for static plots.

#Relies on Matplotlib for any interactive capabilities.

### 4. Performance with Large Datasets
<b>Matplotlib:</b>

#Generally better performance when properly optimized.

#Can efficiently handle large datasets by controlling rendering and simplification.

<b>Seaborn:</b>

#May become slow with large datasets due to built-in statistical computations (e.g., pairplot, histplot).

#Not ideal for big data visualizations without preprocessing or sampling.




```python

```
